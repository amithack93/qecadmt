@extends('layouts.blanklayout')

@section('content')
<div class="wrapper-page">
    <div class="card">
        <div class="card-body">
            <h3 class="text-center mt-0">
                <a href="index-2.html" class="logo logo-admin">
                    <img src="{{ asset('assets/images/logo.png') }}" height="20" alt="logo">
                </a>
            </h3>
            <h6 class="text-center">Sign In
            </h6>
            <div class="p-3">
                <form class="form-horizontal" method="post" action="{{ route('login') }}">
                    @csrf
                    <div class="form-group row">
                        <div class="col-12">
                            <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" placeholder="Email" name="email" value="{{ old('email') }}" required autofocus>
                            @if ($errors->has('email'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-12">
                            <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="Password" required>
                            @if ($errors->has('password'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group text-center row m-t-20">
                        <div class="col-12">
                            <button class="btn btn-danger btn-block waves-effect waves-light" type="submit">Log In
                            </button>
                        </div>
                    </div>
                    <div class="form-group m-t-10 mb-0 row">
                        <div class="col-sm-7 m-t-20">
                            <a href="{{ url('/password/reset') }}" class="text-muted">
                                <i class="mdi mdi-lock">
                                </i> Forgot your password ?
                            </a>
                        </div>
                        <div class="col-sm-5 m-t-20">
                            <a href="{{ url('/register') }}" class="text-muted">
                                <i class="mdi mdi-account-circle">
                                </i> Create an account ?
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
