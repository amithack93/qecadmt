@extends('layouts.blanklayout')

@section('content')
<div class="wrapper-page">
    <div class="card">
        <div class="card-body">
            <h3 class="text-center mt-0">
                <a href="index-2.html" class="logo logo-admin">
                    <img src="{{ asset('assets/images/logo.png') }}" height="20" alt="logo">
                </a>
            </h3>
            <h6 class="text-center">Recover Password</h6>
            <div class="p-3">
                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif
                
                <form method="POST" class="form-horizontal" action="{{ route('password.email') }}" aria-label="{{ __('Reset Password') }}">
                    @csrf

                    <div class="alert alert-primary alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Enter your <b>Email</b> and instructions will be sent to you!</div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" placeholder="Email" value="{{ old('email') }}" required>

                            @if ($errors->has('email'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>
                    <div class="form-group text-center row m-t-20">
                        <div class="col-12"><button class="btn btn-danger btn-block waves-effect waves-light" type="submit"> {{ __('Send Password Reset Link') }}</button></div>
                    </div>
                </form>
                <div class="form-group m-t-10 mb-0 row">
                    <div class="col-12 m-t-20 text-center"><a href="{{ url('/login') }}" class="text-muted">Back to login</a></div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
