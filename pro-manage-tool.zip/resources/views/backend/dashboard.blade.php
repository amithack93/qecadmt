@extends('layouts.backendlayout')

@section('title','Dashboard')

@section('page-title','Dashboard')

@section('content')

@stop