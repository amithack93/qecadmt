<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
	<title> <?php echo $__env->yieldContent('title'); ?> | Project Management Tool</title>
	<meta content="Admin Dashboard" name="description">
	<meta content="themesdesign" name="author">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
	<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
	<?php echo $__env->yieldContent('css'); ?>
</head>

<body class="fixed-left">
	<!-- Begin page -->
	<!--<div class="accountbg"></div>-->
	<div id="stars">
	</div>
	<div id="stars2">
	</div>
	<?php echo $__env->yieldContent('content'); ?>
	
	<!-- jQuery  -->
	<script src=""<?php echo e(asset('assets/js/jquery.min.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/popper.min.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/bootstrap.min.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/modernizr.min.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/detect.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/fastclick.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/jquery.blockUI.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/waves.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/jquery.nicescroll.js')); ?>">
	</script>
	<script src=""<?php echo e(asset('assets/js/jquery.scrollTo.min.js')); ?>">
	</script>
	<!-- App js -->
	<script src=""<?php echo e(asset('assets/js/app.js')); ?>">	</script>
	<?php echo $__env->yieldContent('js'); ?>
</body>
</html>