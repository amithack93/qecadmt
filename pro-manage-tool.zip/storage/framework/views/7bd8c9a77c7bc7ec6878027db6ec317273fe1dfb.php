<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
	<title> <?php echo $__env->yieldContent('title'); ?> | Project Management Tool</title>
	<meta content="Admin Dashboard" name="description">
	<meta content="themesdesign" name="author">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
	<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
	<?php echo $__env->yieldContent('css'); ?>
</head>

<body class="fixed-left">
	<!-- Begin page -->
	<div id="wrapper">
		<!-- ========== Left Sidebar Start ========== -->
		<div class="left side-menu"><button type="button" class="button-menu-mobile button-menu-mobile-topbar open-left"><i class="ion-close"></i></button>
			<!-- LOGO -->
			<div class="topbar-left">
				<div class="text-center">
					<!--<a href="index.html" class="logo"><i class="fa fa-paw"></i> Aplomb</a>-->
					<a href="index-2.html" class="logo"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" height="14" alt="logo"></a>
				</div>
			</div>
			<div class="sidebar-inner slimscrollleft" id="sidebar-main">
				<div id="sidebar-menu">
					<ul>
						<li class="menu-title">Overview</li>
						<li class="has_sub">
							<a href="<?php echo e(url('/dashboard')); ?>" class="waves-effect waves-light"><i class="mdi mdi-view-dashboard"></i><span> Dashboard </span>
							</a>
						</li>
						<li class="has_sub"><a href="javascript:void(0);" class="waves-effect waves-light"><i class="mdi mdi-email"></i><span> Email </span><span class="float-right"><i class="mdi mdi-chevron-right"></i></span></a>
							<ul class="list-unstyled">
								<li><a href="email-inbox.html">Inbox</a></li>
								<li><a href="email-compose.html">Compose Mail</a></li>
								<li><a href="email-read.html">View Mail</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div>
			<!-- end sidebarinner -->
		</div>
		<!-- Left Sidebar End -->
		<!-- Start right Content here -->
		<div class="content-page">
			<!-- Start content -->
			<div class="content">
				<!-- Top Bar Start -->
				<div class="topbar">
					<nav class="navbar-custom">
						<ul class="list-inline float-right mb-0">
							<li class="list-inline-item dropdown notification-list"><a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false"><i class="ti-email noti-icon"></i> <span class="badge badge-danger noti-icon-badge">5</span></a>
								<div
								class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-menu-lg">
								<!-- item-->
								<div class="dropdown-item noti-title">
									<h5><span class="badge badge-danger float-right">5</span>Messages</h5>
								</div>
								<!-- item-->
								<a href="javascript:void(0);" class="dropdown-item notify-item">
									<div class="notify-icon"><img src="<?php echo e(asset('assets/images/users/avatar-2.jpg')); ?>" alt="user-img" class="img-fluid rounded-circle"></div>
									<p class="notify-details"><b>Charles M. Jones</b><small class="">Dummy text of the printing and typesetting industry.</small></p>
								</a>
								<!-- item-->

								<div class="dropdown-divider"></div>
								<!-- All--><a href="javascript:void(0);" class="dropdown-item notify-item">View All</a></div>
							</li>
							<li class="list-inline-item dropdown notification-list"><a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false"><i class="ti-bell noti-icon"></i> <span class="badge badge-success noti-icon-badge">9</span></a>
								<div
								class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-menu-lg">
								<!-- item-->
								<div class="dropdown-item noti-title">
									<h5><span class="badge badge-success float-right">9</span>Notification</h5>
								</div>
								<!-- item-->
								<a href="javascript:void(0);" class="dropdown-item notify-item">
									<div class="notify-icon bg-primary"><i class="mdi mdi-cart-outline"></i></div>
									<p class="notify-details"><b>Your order is placed</b><small class="">Dummy text of the printing and typesetting industry.</small></p>
								</a>

								<div class="dropdown-divider"></div>
								<!-- All-->
								<a href="javascript:void(0);" class="dropdown-item notify-item">View All</a></div>
							</li>
							<li class="list-inline-item dropdown notification-list">
								<a class="nav-link dropdown-toggle arrow-none waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false"><img src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>" alt="user" class="rounded-circle"></a>
								<div class="dropdown-menu dropdown-menu-right profile-dropdown">
									<!-- item-->
									<div class="dropdown-item noti-title">
										<h5>Welcome <?php echo e(Auth::user()->name); ?></h5>
									</div>
									<a class="dropdown-item" href="#"><i class="mdi mdi-account-circle"></i> Profile</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item text-danger" href="<?php echo e(url('/logout')); ?>">
										<i class="mdi mdi-power text-danger"></i> Logout
									</a>
								</div>
							</li>
						</ul>
						<div class="clearfix"></div>
					</nav>
				</div>
				<!-- Top Bar End -->
				<div class="page-content-wrapper">
					<div class="container-fluid">
						<div class="row">
							<div class="col-sm-12">
								<div class="page-title-box">
									<div class="float-right">
										<?php echo $__env->yieldContent('action'); ?>
										<!-- <div class="dropdown">
										<button class="btn btn-secondary btn-round  px-3" type="button" >Settings</button>
									</div> -->
								</div>
								<h4 class="page-title"><?php echo $__env->yieldContent('page-title'); ?></h4>
							</div>
						</div>
					</div>
					<!-- end page title end breadcrumb -->
					<?php echo $__env->yieldContent('content'); ?>
					<!-- end row -->
				</div>
				<!-- container -->
			</div>
			<!-- Page content Wrapper -->
		</div>
		<!-- content -->
		<footer class="footer">
			© <?php echo e(date('Y')); ?> Designed & Developed by <a href="http://xodecwebstudio.com">Xodec Web Studio</a>.
		</footer>
	</div>
	<!-- End Right content here -->
</div>
<!-- END wrapper -->
<!-- jQuery  -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/detect.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/fastclick.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.blockUI.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.scrollTo.min.js')); ?>"></script>
<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>

</html>